#include "HardMaterial.h"
#include <iostream>
#include <string>
using namespace std;

HardMaterial::HardMaterial(){}

HardMaterial::HardMaterial(int volume){
    this->volume = volume;
}