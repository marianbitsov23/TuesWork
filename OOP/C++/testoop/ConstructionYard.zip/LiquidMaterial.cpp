#include <iostream>
#include "LiquidMaterial.h"
#include <string>
using namespace std;

LiquidMaterial::LiquidMaterial(){}

LiquidMaterial::LiquidMaterial(int count){
    this->count = count;
}